package me.bobit.myapp.login.service;

import me.bobit.myapp.member.service.MemberVO;

public interface LoginService {

	Boolean login(MemberVO vo);

//	void add(MemberVO vo);
	
	

}
