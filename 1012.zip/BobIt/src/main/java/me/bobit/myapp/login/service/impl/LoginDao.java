package me.bobit.myapp.login.service.impl;

import me.bobit.myapp.member.service.MemberVO;

public interface LoginDao {

	MemberVO login(MemberVO vo);

//	void add(MemberVO vo);

}
