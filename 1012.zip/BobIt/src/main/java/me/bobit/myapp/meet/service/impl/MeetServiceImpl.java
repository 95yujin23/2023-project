package me.bobit.myapp.meet.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import me.bobit.myapp.Pager;
import me.bobit.myapp.meet.service.MeetService;
import me.bobit.myapp.meet.service.MeetVO;
import me.bobit.myapp.mtapply.service.MtapplyVO;

@Service
public class MeetServiceImpl implements MeetService {
	@Autowired
	MeetDao dao;	
	
	@Override
	public List<MeetVO> selectMeetList(Pager pager) {
		int total = dao.total(pager);

		pager.setTotal(total);
		
		return dao.selectMeetList(pager);
	}

	@Override
	public void insertMeet(MeetVO vo, MeetVO jvo) {
		dao.insertMeet(vo);
		
		
		int jmeetno = dao.selectLastInsertedMeetNo();
		String jvomemnick = vo.getMemNick();
		
		jvo = new MeetVO();
		jvo.setMeetNo(jmeetno);
		jvo.setMemNick(jvomemnick);
		
		dao.insertMeetJang(jvo);		
	}

	@Override
	public MeetVO selectMeet(int meetNo) {
		return dao.selectMeet(meetNo);
	}

	@Override
	public void updateMeet(MeetVO vo) {
		dao.updateMeet(vo);
	}

	@Override
	public void deleteMeet(int meetNo) {
		dao.deleteMeet(meetNo);
	}

	@Override
	public void insertMeetJang(MeetVO vo) {
		dao.insertMeetJang(vo);	
	}
	
}
