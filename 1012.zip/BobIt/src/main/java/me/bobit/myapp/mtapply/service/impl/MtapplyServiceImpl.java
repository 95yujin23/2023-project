package me.bobit.myapp.mtapply.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.bobit.myapp.Pager;
import me.bobit.myapp.mtapply.service.MtapplyService;
import me.bobit.myapp.mtapply.service.MtapplyVO;

@Service
public class MtapplyServiceImpl implements MtapplyService {
	@Autowired
	MtapplyDao dao;
	
	@Override
	public List<MtapplyVO> selectMtapplyList(Pager pager)  throws Exception{
		int total = dao.total(pager);
		
		pager.setTotal(total);
		
		return dao.selectMtapplyList(pager);
	}

	@Override
	public MtapplyVO selectMtapply(int mtapplyNo)  throws Exception{
		return dao.selectMtapply(mtapplyNo);
	}

	@Override
	public void insertMtapply(MtapplyVO vo)  throws Exception{
		dao.insertMtapply(vo);
	}

	@Override
	public void agreeMtapply(int mtapplyNo)  throws Exception{
		dao.agreeMtapply(mtapplyNo);
	}

	@Override
	public void deniedMtapply(int mtapplyNo)  throws Exception{
		dao.deniedMtapply(mtapplyNo);
	}

	@Override
	public void waitMtapply(int mtapplyNo)  throws Exception{
		dao.waitMtapply(mtapplyNo);
	}

	@Override
	public List<MtapplyVO> selectMeetApplyList(int meetNo) {
		return dao.selectMeetApplyList(meetNo);
		
	}


	



}
